J MATH TOOLKIT
   Aplikasi
Matematika sederhana 
     oleh
    Jhonny

1. Operasi Dasar
   - Penjumlahan 
   - Pengurangan 
   - Perkalian 
   - Pembagian 

2. Pangkat & Akar
   - Pangkat
   - Akar kuadrat 
   - Akar pangkat n

3. Faktorial
   - Menghitung faktorial (n!)
   - Mendukung bilangan hingga 100

4. FPB & KPK
   - FPB (Faktor Persekutuan Terbesar)
   - KPK (Kelipatan Persekutuan Terkecil)

5. Bilangan Prima
   - Cek apakah bilangan prima
   - Daftar bilangan prima dari 1 sampai n

6. Persamaan Linear
   - Menyelesaikan persamaan ax + b = 0

7. Statistik
   - Menghitung rata-rata (mean)
   - Menghitung median
   
Instalasi untuk Linux/Termux
Linux
sudo apt update 
sudo apt install python3 python3-pip
PIP install colorama

Termux
pkg update
pkg install python
PIP install colorama


